<!DOCTYPE html>
<html lang="en">

<head> 
    <title> Booking Confirmation </title>    
    <meta charset="utf-8">
</head>

<body>
    <header><h1> Rohirrim Tour Booking Confirmation </h1></header>
    
    <?php

    function sanitize_input ($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

    if (isset($_POST["firstname"])) {
    $err_msg="";
    $firstname = $_POST["firstname"];
    $lastname = $_POST["lastname"];
    
    }

    //Fname
    if (trim($firstname)=="")
        $err_msg .= "<p> Please enter first name. </p>";
    else {
        $firstname=sanitize_input($firstname);
        if(!preg_match("/^[a-zA-Z]{2,40}$/",$firstname)){
            $err_msg .= "<p> Only letters are allowed in first name. </p>";
        }
    }
    
    //Lname
    if (trim($lastname)=="")
        $err_msg .= "<p> Please enter last name. </p>";
    else {
        $lastname=sanitize_input($lastname);
        if(!preg_match("/^[a-zA-Z]{2,40}$/",$lastname)){
            $err_msg .= "<p> Only letters are allowed in last name. </p>";
        }
    }    

    // error msg, welcome info
    if ($err_msg!="")
        echo $err_msg;
    else {
        echo 
        "<p> Welcome $firstname $lastname! </p> 
        <p> You are now booked on the $oneday and $fourday </p>
        <p> Species: $H </p>
        <p> Age: $age </p>
        <p> Meal preference: $mushrooms </p>
        <p> Number of travellers: $partysize </p>" 
    }

    else {
    header ("location:register.html"); //redirect back
    }

    ?>

</body>
</html>
